using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace LiveScoreAPP.Pages.Kabaddi
{
    public class KabaddiModel : PageModel
    {
             public List<Kabaddi> listKabaddi = new List<Kabaddi>();

        public String errorMsg = "";
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=LiveDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM Kabaddi";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Kabaddi kabaddi = new Kabaddi();
                                kabaddi.ID = "" + reader.GetInt64(0);
                                kabaddi.MatchStatus = reader.GetString(1);
                                kabaddi.Status = reader.GetString(2);
                                kabaddi.PointA = reader.GetString(3);
                                kabaddi.PointB = reader.GetString(4);
                                kabaddi.TeamA = reader.GetString(5);
                                kabaddi.TeamB = reader.GetString(6);
                                kabaddi.MatchNumber = reader.GetString(7);
                                kabaddi.League = reader.GetString(8);
                                kabaddi.Time = reader.GetString(9);
                                kabaddi.Date = reader.GetString(10);
                                kabaddi.ImageA = reader.GetString(11);
                                kabaddi.ImageB = reader.GetString(12);
                                
                  
                                listKabaddi.Add(kabaddi);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                errorMsg = ex.Message;
                Console.WriteLine("Exception: ");
                return;
            }
        }
    }
    public class Kabaddi
    {
        public String? ID;
        public String? MatchStatus;
        public String? Status;
        public String? PointA;
        public String? PointB;
        public String? TeamA;
        public String? TeamB;
        public String? MatchNumber;
        public String? League;
        public String? Time;
        public String? Date;
        public String? ImageA;
        public String? ImageB;
    }
}
    

