using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LiveScoreAPP.Pages.Football
{
    public class FootballModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
