using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace LiveScoreAPP.Pages.Cricket
{
    public class CricketModel : PageModel
    {
        public List<Cricket> listCricket = new List<Cricket>();

        public String errorMsg = "";
        public void OnGet()
        {
            try {
                String connectionString = "Data Source=.\\sqlexpress;Initial Catalog=LiveDB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM Cricket";
                    using(SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Cricket cricket = new Cricket();
                                cricket.ID = "" + reader.GetInt64(0);
                                cricket.Category = reader.GetString(1);
                                cricket.League = reader.GetString(2);
                                cricket.Time= reader.GetString(3);
                                cricket.Date= reader.GetString(4);
                                cricket.ImageA= reader.GetString(5);
                                cricket.ImageB= reader.GetString(6);
                                cricket.MatchNumber= reader.GetString(7);
                                cricket.OverA= reader.GetString(8);
                                cricket.OverB= reader.GetString(9);
                                cricket.ScoreA= reader.GetString(10);
                                cricket.ScoreB= reader.GetString(11);
                                cricket.TeamA= reader.GetString(12);
                                cricket.TeamB= reader.GetString(13);
                                cricket.WicketA= reader.GetString(14);
                                cricket.WicketB= reader.GetString(15);
                                cricket.MatchStatus=reader.GetString(16);
                           
                                listCricket.Add(cricket);
                            }
                        }
                    }
                }
            }
            catch (Exception  ex)
            {

                errorMsg = ex.Message;
                Console.WriteLine("Exception: ");
                return; 
            }
        }
    }
    public class Cricket
    {
        public String? ID ;
        public String? Category;
        public String? League;
        public String? Time;
        public String? Date;
        public String? ImageA;
        public String? ImageB;
        public String? MatchNumber;
        public String? OverA;
        public String? OverB;
        public String? ScoreA;
        public String? ScoreB;
        public String? TeamA;
        public String? TeamB;
        public String? WicketA;
        public String? WicketB; 
        public String? MatchStatus;
    }
}
