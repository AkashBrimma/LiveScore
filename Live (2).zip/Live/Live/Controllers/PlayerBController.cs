﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Live.Models;

namespace Live.Controllers
{
    public class PlayerBController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();

            string query = @" select * from dbo.PlayerB";

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        public string Post(PlayerB player)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           insert into dbo.PlayerB 
                           (Player1, Player2, Player3, Player4, Player5,  
                           Player6, Player7, Player8, Player9, Player10,
                           Player11, Player12, Player13, Player14, Player15 )
                            Values(
                            '" + player.Player1 + @"'
                            ,'" + player.Player2 + @"'
                            ,'" + player.Player3 + @"'
                            ,'" + player.Player4 + @"'
                            ,'" + player.Player5 + @"'
                            ,'" + player.Player6 + @"'
                            ,'" + player.Player7 + @"'
                            ,'" + player.Player8 + @"'
                            ,'" + player.Player9 + @"'
                            ,'" + player.Player10 + @"'
                            ,'" + player.Player11 + @"'
                            ,'" + player.Player12 + @"'
                            ,'" + player.Player13 + @"'
                            ,'" + player.Player14 + @"'
                            ,'" + player.Player15 + @"'
                            )
                            ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Add";
            }
        }
        public string Put(PlayerB player)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                          update dbo.PlayerB set
                          Player1 = '" + player.Player1 + @"'
                          ,Player2 = '" + player.Player2 + @"'
                          ,Player3 = '" + player.Player3 + @"'
                          ,Player4 = '" + player.Player4 + @"'
                          ,Player5 = '" + player.Player5 + @"'
                          ,Player6 = '" + player.Player6 + @"'
                          ,Player7 = '" + player.Player7 + @"'
                          ,Player8 = '" + player.Player8 + @"'
                          ,Player9 = '" + player.Player9 + @"'
                          ,Player10 = '" + player.Player10 + @"'
                          ,Player11 = '" + player.Player11 + @"'
                          ,Player12 = '" + player.Player12 + @"'
                          ,Player13 = '" + player.Player13 + @"'
                          ,Player14 = '" + player.Player14 + @"'
                          ,Player15 = '" + player.Player15 + @"'
                          where ID = " + player.ID + @"
                           ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Update Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Update";
            }
        }
        public string Delete(int id)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           delete from dbo.PlayerB where ID = " + id;

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Delete Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Delete";
            }
        }
    }
}
