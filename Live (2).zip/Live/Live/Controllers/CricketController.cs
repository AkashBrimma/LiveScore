﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Live.Models;

namespace Live.Controllers
{
    public class CricketController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();

            string query = @"
                           select ID, Category, League, Time, Date, 
                           ImageA, ImageB, MatchNumber, OverA, OverB,
                           ScoreA, ScoreB, TeamA, TeamB, WicketA,
                           WicketB, MatchStatus
                           from dbo.Cricket";

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        public string Post(Cricket cri)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           insert into dbo.Cricket 
                           (Category, League, Time, Date, 
                           ImageA, ImageB, MatchNumber, OverA, 
                           OverB, ScoreA, ScoreB, TeamA, 
                           TeamB, WicketA, WicketB, MatchStatus)
                            Values(
                            '" + cri.Category + @"'
                            ,'" + cri.League + @"'
                            ,'" + cri.Time + @"'
                            ,'" + cri.Date + @"'
                            ,'" + cri.ImageA + @"'
                            ,'" + cri.ImageB + @"'
                            ,'" + cri.MatchNumber+ @"'
                            ,'" + cri.OverA + @"'
                            ,'" + cri.OverB + @"'
                            ,'" + cri.ScoreA + @"'
                            ,'" + cri.ScoreB + @"'
                            ,'" + cri.TeamA + @"'
                            ,'" + cri.TeamB + @"'
                            ,'" + cri.WicketA + @"'
                            ,'" + cri.WicketB + @"'
                            ,'" + cri.MatchStatus + @"'
                            )
                            ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Add";
            }
        }

        public string Put(Cricket cri)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                          update dbo.Cricket set
                          Category = '" + cri.Category + @"'
                          ,League = '" + cri.League + @"'
                          ,Time = '" + cri.Time + @"'
                          ,Date = '" + cri.Date + @"'
                          ,ImageA = '" + cri.ImageA + @"'
                          ,ImageB = '" + cri.ImageB + @"'
                          ,MatchNumber = '" + cri.MatchNumber + @"'
                          ,OverA = '" + cri.OverA + @"'
                          ,OverB = '" + cri.OverB + @"'
                          ,ScoreA = '" + cri.ScoreA + @"'
                          ,ScoreB = '" + cri.ScoreB + @"'
                          ,TeamA = '" + cri.TeamA + @"'
                          ,TeamB = '" + cri.TeamB + @"'
                          ,WicketA = '" + cri.WicketA + @"'
                          ,WicketB = '" + cri.WicketB + @"'
                          ,MatchStatus = '" + cri.MatchStatus +@"'
                          where ID = " + cri.ID + @"
                           ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Update Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Update";
            }
        }

        public string Delete(int id)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           delete from dbo.Cricket where ID = " + id;

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Delete Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Delete";
            }
        }
    }
}
