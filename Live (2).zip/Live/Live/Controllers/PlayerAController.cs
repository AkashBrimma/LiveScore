﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Live.Models;

namespace Live.Controllers
{
    public class PlayerAController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();

            string query = @" select * from dbo.PlayerA";

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        public string Post(PlayerA play)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           insert into dbo.PlayerA 
                           (Player1, Player2, Player3, Player4, Player5,  
                           Player6, Player7, Player8, Player9, Player10,
                           Player11, Player12, Player13, Player14, Player15 )
                            Values(
                            '" + play.Player1 + @"'
                            ,'" + play.Player2 + @"'
                            ,'" + play.Player3 + @"'
                            ,'" + play.Player4 + @"'
                            ,'" + play.Player5 + @"'
                            ,'" + play.Player6 + @"'
                            ,'" + play.Player7 + @"'
                            ,'" + play.Player8 + @"'
                            ,'" + play.Player9 + @"'
                            ,'" + play.Player10 + @"'
                            ,'" + play.Player11 + @"'
                            ,'" + play.Player12 + @"'
                            ,'" + play.Player13 + @"'
                            ,'" + play.Player14 + @"'
                            ,'" + play.Player15 + @"'
                            )
                            ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Add";
            }
        }
        public string Put(PlayerA play)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                          update dbo.PlayerA set
                          Player1 = '" + play.Player1 + @"'
                          ,Player2 = '" + play.Player2 + @"'
                          ,Player3 = '" + play.Player3 + @"'
                          ,Player4 = '" + play.Player4 + @"'
                          ,Player5 = '" + play.Player5 + @"'
                          ,Player6 = '" + play.Player6 + @"'
                          ,Player7 = '" + play.Player7 + @"'
                          ,Player8 = '" + play.Player8 + @"'
                          ,Player9 = '" + play.Player9 + @"'
                          ,Player10 = '" + play.Player10 + @"'
                          ,Player11 = '" + play.Player11 + @"'
                          ,Player12 = '" + play.Player12 + @"'
                          ,Player13 = '" + play.Player13 + @"'
                          ,Player14 = '" + play.Player14 + @"'
                          ,Player15 = '" + play.Player15 + @"'
                          where ID = " + play.ID + @"
                           ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Update Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Update";
            }
        }
        public string Delete(int id)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           delete from dbo.PlayerA where ID = " + id;

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Delete Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Delete";
            }
        }
    }
}
