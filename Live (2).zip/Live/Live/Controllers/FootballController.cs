﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Live.Models;
using System.Drawing;

namespace Live.Controllers
{
    public class FootballController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();

            string query = @"
                           select ID, MatchStatus, Status, GoalA, GoalB, TeamA, TeamB, MatchNumber, League, Time, Date, 
                           ImageA, ImageB
                           from dbo.Football";

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        public string Post(Football foot)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           insert into dbo.Football 
                           (MatchStatus, Status, GoalA, GoalB, TeamA, TeamB, MatchNumber, League, Time, Date, 
                           ImageA, ImageB)
                            Values(
                            '" + foot.MatchStatus + @"'
                            ,'" + foot.Status + @"'
                            ,'" + foot.GoalA + @"'
                            ,'" + foot.GoalB + @"'
                            ,'" + foot.TeamA + @"'
                            ,'" + foot.TeamB + @"'
                            ,'" + foot.MatchNumber + @"'
                            ,'" + foot.League + @"'
                            ,'" + foot.Time + @"'
                            ,'" + foot.Date + @"'
                            ,'" + foot.ImageA + @"'
                            ,'" + foot.ImageB + @"'
                            )
                            ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Add";
            }
        }

        public string Put(Football foot)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                          update dbo.Football set
                          MatchStatus = '" + foot.MatchStatus + @"'
                          ,Status = '" + foot.Status + @"'
                          ,GoalA = '" + foot.GoalA + @"'
                          ,GoalB = '" + foot.GoalB + @"'
                          ,TeamA = '" + foot.TeamA + @"'
                          ,TeamB = '" + foot.TeamB + @"'
                          ,MatchNumber = '" + foot.MatchNumber + @"'
                          ,League = '" + foot.League + @"'
                          ,Time = '" + foot.Time + @"'
                          ,Date = '" + foot.Date + @"'
                          ,ImageA = '" + foot.ImageA + @"'
                          ,ImageB = '" + foot.ImageB + @"'
                          where ID = " + foot.ID + @"
                           ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Update Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Update";
            }
        }

        public string Delete(int id)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           delete from dbo.Football where ID = " + id;

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Delete Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Delete";
            }
        }
    }
}
