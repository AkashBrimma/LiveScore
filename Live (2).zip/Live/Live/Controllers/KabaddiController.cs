﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Live.Models;

namespace Live.Controllers
{
    public class KabaddiController : ApiController
    {
        public HttpResponseMessage Get()
        {
            DataTable table = new DataTable();

            string query = @"
                           select ID, MatchStatus, Status, PointA, PointB, TeamA, TeamB, MatchNumber, League, Time, Date, 
                           ImageA, ImageB
                           from dbo.Kabaddi";

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        public string Post(Kabaddi kab)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           insert into dbo.Kabaddi 
                           (MatchStatus, Status, PointA, PointB, TeamA, TeamB, MatchNumber, League, Time, Date, 
                           ImageA, ImageB)
                            Values(
                            '" + kab.MatchStatus + @"'
                            ,'" + kab.Status + @"'
                            ,'" + kab.PointA + @"'
                            ,'" + kab.PointB + @"'
                            ,'" + kab.TeamA + @"'
                            ,'" + kab.TeamB + @"'
                            ,'" + kab.MatchNumber + @"'
                            ,'" + kab.League + @"'
                            ,'" + kab.Time + @"'
                            ,'" + kab.Date + @"'
                            ,'" + kab.ImageA + @"'
                            ,'" + kab.ImageB + @"'
                            )
                            ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Add";
            }
        }

        public string Put(Kabaddi kab)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                          update dbo.Kabaddi set
                          MatchStatus = '" + kab.MatchStatus + @"'
                          ,Status = '" + kab.Status + @"'
                          ,PointA = '" + kab.PointA + @"'
                          ,PointB = '" + kab.PointB + @"'
                          ,TeamA = '" + kab.TeamA + @"'
                          ,TeamB = '" + kab.TeamB + @"'
                          ,MatchNumber = '" + kab.MatchNumber + @"'
                          ,League = '" + kab.League + @"'
                          ,Time = '" + kab.Time + @"'
                          ,Date = '" + kab.Date + @"'
                          ,ImageA = '" + kab.ImageA + @"'
                          ,ImageB = '" + kab.ImageB + @"'
                          where ID = " + kab.ID + @"
                           ";

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Update Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Update";
            }
        }

        public string Delete(int id)
        {
            try
            {
                DataTable table = new DataTable();

                string query = @"
                           delete from dbo.Kabaddi where ID = " + id;

                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["LiveAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Delete Successfully";
            }
            catch (Exception ex)
            {
                return "Failed to Delete";
            }
        }
    }
}
