﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Live.Models
{
    public class PlayerB
    {
        public long ID { get; set; }
        public string Player1 { get; set; }

        public string Player2 { get; set; }
        public string Player3 { get; set; }
        public string Player4 { get; set; }
        public string Player5 { get; set; }
        public string Player6 { get; set; }
        public string Player7 { get; set; }
        public string Player8 { get; set; }
        public string Player9 { get; set; }
        public string Player10 { get; set; }
        public string Player11 { get; set; }
        public string Player12 { get; set; }
        public string Player13 { get; set; }
        public string Player14 { get; set; }
        public string Player15 { get; set; }
    }
}