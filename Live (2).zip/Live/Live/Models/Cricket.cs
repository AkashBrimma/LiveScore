﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Live.Models
{
    public class Cricket
    {
        public long ID { get; set; }
        public string Category { get; set; }
        public string League { get; set; }
        public string Time { get; set; }
        public string Date { get; set; }
        public string ImageA { get; set; }
        public string ImageB { get; set; }
        public string MatchNumber { get; set; }
        public string OverA { get; set; }
        public string OverB { get; set; }
        public string ScoreA { get; set; }
        public string ScoreB { get; set; }
        public string TeamA { get; set; }
        public string TeamB { get; set; }
        public string WicketA { get; set; }
        public string WicketB { get; set;}
        public string MatchStatus { get; set;}
    }
}