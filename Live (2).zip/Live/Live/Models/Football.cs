﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Live.Models
{
    public class Football
    {
        public long ID { get; set; }
        public string MatchStatus { get; set; }
        public string Status { get; set; }
        public string GoalA { get; set; }
        public string GoalB { get; set; }
        public string TeamA { get; set; }
        public string TeamB { get; set; }
        public string MatchNumber { get; set; }
        public string League { get; set; }
        public string Time { get; set; }
        public string Date { get; set; }
        public string ImageA { get; set; }
        public string ImageB { get; set; }
    }
}