﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Live.Models
{
    public class Kabaddi_PlayerA
    {
        public long ID { get; set; }
        public string PlayerA1 { get; set; }

        public string PlayerA2 { get; set; }
        public string PlayerA3 { get; set; }
        public string PlayerA4 { get; set; }
        public string PlayerA5 { get; set; }
        public string PlayerA6 { get; set; }
        public string PlayerA7 { get; set; }
        public string PlayerAS1 { get; set; }
        public string PlayerAS2 { get; set; }
        public string PlayerAS3 { get; set; }
        public string PlayerAS4 { get; set; }
        public string PlayerAS5 { get; set; }
        public string PlayerAS6 { get; set; }
        public string PlayerAS7 { get; set; }
        
    }
}