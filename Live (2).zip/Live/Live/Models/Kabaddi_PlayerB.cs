﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Live.Models
{
    public class Kabaddi_PlayerB
    {
        public long ID { get; set; }
        public string PlayerB1 { get; set; }

        public string PlayerB2 { get; set; }
        public string PlayerB3 { get; set; }
        public string PlayerB4 { get; set; }
        public string PlayerB5 { get; set; }
        public string PlayerB6 { get; set; }
        public string PlayerB7 { get; set; }
        public string PlayerBS1 { get; set; }
        public string PlayerBS2 { get; set; }
        public string PlayerBS3 { get; set; }
        public string PlayerBS4 { get; set; }
        public string PlayerBS5 { get; set; }
        public string PlayerBS6 { get; set; }
        public string PlayerBS7 { get; set; }
    }
}